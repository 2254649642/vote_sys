package com.cq.edu.pojo;

public class Authority {
    private String id;
    private String role_code ;
    private String role_name ;

    public String getRole_code() {
        return role_code;
    }

    public void setRole_code(String role_code) {
        this.role_code = role_code;
    }

    public String getRole_name() {
        return role_name;
    }

    public void setRole_name(String role_name) {
        this.role_name = role_name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAuthority() {
        return role_code;
    }

    public void setAuthority(String role_code) {
        this.role_code = role_code;
    }
}

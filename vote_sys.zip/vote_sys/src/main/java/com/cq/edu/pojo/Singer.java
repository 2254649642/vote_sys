package com.cq.edu.pojo;

public class Singer {
    private String id;
    private String real_name;
    private String sex;
    private String telephone;
    private String player_music;
    private String player_opus;
    private String take_state;

    public String getTake_state() {
        return take_state;
    }

    public void setTake_state(String take_state) {
        this.take_state = take_state;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getReal_name() {
        return real_name;
    }

    public void setReal_name(String real_name) {
        this.real_name = real_name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getPlayer_music() {
        return player_music;
    }

    public void setPlayer_music(String player_music) {
        this.player_music = player_music;
    }

    public String getPlayer_opus() {
        return player_opus;
    }

    public void setPlayer_opus(String player_opus) {
        this.player_opus = player_opus;
    }
}

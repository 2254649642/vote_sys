package com.cq.edu.pojo;

public class VoteDetails {
    private String player_a_music;
    private String player_b_music;
    private String player_a;
    private String player_b;
    private String a_song;
    private String b_song;
    private String player_a_poll;
    private String player_b_poll;
    private String player_a_id;
    private String player_b_id;
    private String player_a_score;
    private String player_b_score;

    public String getPlayer_a_score() {
        return player_a_score;
    }

    public void setPlayer_a_score(String player_a_score) {
        this.player_a_score = player_a_score;
    }

    public String getPlayer_b_score() {
        return player_b_score;
    }

    public void setPlayer_b_score(String player_b_score) {
        this.player_b_score = player_b_score;
    }

    public String getPlayer_a_id() {
        return player_a_id;
    }

    public void setPlayer_a_id(String player_a_id) {
        this.player_a_id = player_a_id;
    }

    public String getPlayer_b_id() {
        return player_b_id;
    }

    public void setPlayer_b_id(String player_b_id) {
        this.player_b_id = player_b_id;
    }

    public String getPlayer_a_music() {
        return player_a_music;
    }

    public void setPlayer_a_music(String player_a_music) {
        this.player_a_music = player_a_music;
    }

    public String getPlayer_b_music() {
        return player_b_music;
    }

    public void setPlayer_b_music(String player_b_music) {
        this.player_b_music = player_b_music;
    }

    public String getPlayer_a() {
        return player_a;
    }

    public void setPlayer_a(String player_a) {
        this.player_a = player_a;
    }

    public String getPlayer_b() {
        return player_b;
    }

    public void setPlayer_b(String player_b) {
        this.player_b = player_b;
    }

    public String getA_song() {
        return a_song;
    }

    public void setA_song(String a_song) {
        this.a_song = a_song;
    }

    public String getB_song() {
        return b_song;
    }

    public void setB_song(String b_song) {
        this.b_song = b_song;
    }

    public String getPlayer_a_poll() {
        return player_a_poll;
    }

    public void setPlayer_a_poll(String player_a_poll) {
        this.player_a_poll = player_a_poll;
    }

    public String getPlayer_b_poll() {
        return player_b_poll;
    }

    public void setPlayer_b_poll(String player_b_poll) {
        this.player_b_poll = player_b_poll;
    }
}

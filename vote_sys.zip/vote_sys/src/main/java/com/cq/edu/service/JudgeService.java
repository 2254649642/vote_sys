package com.cq.edu.service;

import com.cq.edu.pojo.Result;
import com.cq.edu.pojo.Score;

public interface JudgeService {

    Result addJudgeScore(Score score);
}

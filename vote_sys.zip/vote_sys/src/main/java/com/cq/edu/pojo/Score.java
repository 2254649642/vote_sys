package com.cq.edu.pojo;

public class Score {
    private String id;
    private String player_id;
    private String judge_id;
    private String match_id;
    private String score;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPlayer_id() {
        return player_id;
    }

    public void setPlayer_id(String player_id) {
        this.player_id = player_id;
    }

    public String getJudge_id() {
        return judge_id;
    }

    public void setJudge_id(String judge_id) {
        this.judge_id = judge_id;
    }

    public String getMatch_id() {
        return match_id;
    }

    public void setMatch_id(String match_id) {
        this.match_id = match_id;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }
}

package com.cq.edu.pojo;

public class SumScore {
    private String id;
    private String player_id;
    private String player_opus;
    private String match_id;
    private String sum_score;
    private String player_name;

    private String score;
    private String player_poll;
    private String result;


    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getPlayer_poll() {
        return player_poll;
    }

    public void setPlayer_poll(String player_poll) {
        this.player_poll = player_poll;
    }

    public String getPlayer_name() {
        return player_name;
    }

    public void setPlayer_name(String player_name) {
        this.player_name = player_name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPlayer_id() {
        return player_id;
    }

    public void setPlayer_id(String player_id) {
        this.player_id = player_id;
    }

    public String getPlayer_opus() {
        return player_opus;
    }

    public void setPlayer_opus(String player_opus) {
        this.player_opus = player_opus;
    }

    public String getMatch_id() {
        return match_id;
    }

    public void setMatch_id(String match_id) {
        this.match_id = match_id;
    }

    public String getSum_score() {
        return sum_score;
    }

    public void setSum_score(String sum_score) {
        this.sum_score = sum_score;
    }
}

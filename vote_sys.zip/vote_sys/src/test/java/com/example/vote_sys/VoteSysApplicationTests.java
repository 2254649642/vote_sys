package com.example.vote_sys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoteSysApplicationTests {

    @Test
    void contextLoads() {
    }

}
